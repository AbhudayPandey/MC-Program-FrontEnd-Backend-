import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { RegistrationService } from '../registration.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-viewcustomer',
  templateUrl: './viewcustomer.component.html',
  styleUrls: ['./viewcustomer.component.css']
})
export class ViewcustomerComponent implements OnInit {

  public pan:String;
  data:any;
  // customer:Customer[];
  user=new User();
  users={};


  constructor(private customerService:RegistrationService,private route: ActivatedRoute) { }

  ngOnInit() {
    this.viewCustomer();
  }

  viewCustomer(){
    this.pan=this.route.snapshot.params.pan;
    console.log(this.pan);
    this.customerService.getCustomerByPan(this.pan).subscribe(data=>{
    this.users=data;
      //  console.log(data);
  })
  }
}