import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Fund } from './fund';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FundService {
  pan:string = window.localStorage.getItem('pan');

  private baseUrl="http://localhost:8083";
  constructor( private _http : HttpClient) { }

  public createFundFromRemote(fund :Fund):Observable<any>{
    return this._http.post<any>("http://localhost:8083/transaction",fund);
  }
  getFundByPan(): Observable<Fund> {
    // return this.http.get<Customer>(`${this.baseUrl}/getCustomer/${userName}`);
    return this._http.get<Fund>(`${this.baseUrl}/fundbypan/${this.pan}`).pipe(map((account:any)=>account));
  }
}
