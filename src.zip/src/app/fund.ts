export class Fund {
    id:number;
    pan:string;
    fundname:string;
    amount:number;
    transactAt:Date;
}
