import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { Fund } from '../fund';
import { Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';
import { FundService } from '../fund.service';

@Component({
  selector: 'app-fund',
  templateUrl: './fund.component.html',
  styleUrls: ['./fund.component.css']
})
export class FundComponent implements OnInit {

  fund = new Fund();
  msg='';

  constructor(private _service : FundService ,private _router : Router) { }

  ngOnInit(): void {
  }

  createFund(){
    this._service.createFundFromRemote(this.fund).subscribe(
      data =>{
        console.log("response recived");
        this.msg="Fund created  successfully";
      },
      error =>{
        console.log("exception occured");
        this.msg=error.error;
      }
    )
  }
}
