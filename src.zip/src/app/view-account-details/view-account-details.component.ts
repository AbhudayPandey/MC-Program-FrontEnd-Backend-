import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Account } from '../account';
import { User } from '../user';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-view-account-details',
  templateUrl: './view-account-details.component.html',
  styleUrls: ['./view-account-details.component.css']
})
export class ViewAccountDetailsComponent implements OnInit {

  public pan:String;
  data:any;
  // customer:Customer[];
  account=new Account();
  accounts={};
  msg: string;

  // user=new User();


  constructor(private customerService:AccountService,private route: ActivatedRoute) { }

//   ngOnInit() {
//     this.viewCustomer();
//   }

//   viewCustomer(){
//     this.pan=this.route.snapshot.params.pan;
//     console.log(this.pan);
//     this.customerService.getAccountByPan(this.pan).subscribe(data=>{
//     this.accounts=data;
//       //  console.log(data);
//   })
//   }

// }
ngOnInit(): void {
  this.pan=window.localStorage.getItem('pan');
  let resp = this.customerService.getAccountByPan();
  resp.subscribe((data) =>{this.accounts= data;
    console.log('account',data)
  },
  error=>{
    console.log("Exception occured");
    this.msg="No account found";
  }
  
  );
}
}

