import { Component, OnInit } from '@angular/core';
import { FundService } from '../fund.service';
import { ActivatedRoute } from '@angular/router';
import { Fund } from '../fund';

@Component({
  selector: 'app-viewmutualfund',
  templateUrl: './viewmutualfund.component.html',
  styleUrls: ['./viewmutualfund.component.css']
})
export class ViewmutualfundComponent implements OnInit {

  public pan:String;
  data:any;
  // customer:Customer[];
  fund=new Fund();
  funds={};
  msg: string;


  constructor(private customerService:FundService,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.pan=window.localStorage.getItem('pan');
    let resp = this.customerService.getFundByPan();
    resp.subscribe((data) =>{this.funds= data;
      console.log('account',data)
    },
    error=>{
      console.log("Exception occured");
      this.msg="No account found";
    }
    
    );
  }
  }
  