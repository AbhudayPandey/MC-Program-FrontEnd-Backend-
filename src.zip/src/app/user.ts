export class User {
    id:number;
    emailId:string;
    userName:string;
    password:string;
    pan:string;
    contact:number;
    constructor(){}
}
