import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  private baseUrl="http://localhost:8082";

  constructor( private _http : HttpClient) { }

  public loginUserFromRemote(user :User):Observable<any>{
    return this._http.post<any>("http://localhost:8082/login",user);
  }

  public registerUserFromRemote(user :User):Observable<any>{
    return this._http.post<any>("http://localhost:8082/registeruser",user);
  }

  getCustomerByPan(pan: String): Observable<User> {
    // return this.http.get<Customer>(`${this.baseUrl}/getCustomer/${userName}`);
    return this._http.get<User>(this.baseUrl+ "/customerbypan/"+ pan);
  }
}
