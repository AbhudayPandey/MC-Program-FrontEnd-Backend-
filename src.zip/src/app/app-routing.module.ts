import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LoginsuccessComponent } from  './loginsuccess/loginsuccess.component';
import { RegistrationComponent } from './registration/registration.component';
import { AccountComponent } from './account/account.component';
import { ViewAccountDetailsComponent } from './view-account-details/view-account-details.component';
import { FundComponent } from './fund/fund.component';
import { ViewcustomerComponent } from './viewcustomer/viewcustomer.component';
import { ViewmutualfundComponent } from './viewmutualfund/viewmutualfund.component';
const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'loginsuccess',component:LoginsuccessComponent},
  {path:'registration',component:RegistrationComponent},
  {path:'login',component:LoginComponent},
  {path:'viewaccount',component:ViewAccountDetailsComponent},
  {path:'fund',component:FundComponent},
  {path:'account',component:AccountComponent},
  {path:'viewmutualfund',component:ViewmutualfundComponent},
  {path:'viewcustomer/:pan',component:ViewcustomerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [LoginsuccessComponent,RegistrationComponent,LoginComponent,ViewAccountDetailsComponent,FundComponent,AccountComponent,ViewmutualfundComponent,ViewcustomerComponent]
