export class Account {
    id:number;
    accountNo:number;
    ifsc:string;
    bankName:string;
    micrCode:number;
    amount:number;
    pan:string;
    constructor(){}
}
