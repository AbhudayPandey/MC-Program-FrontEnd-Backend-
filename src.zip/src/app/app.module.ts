import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
// import { LoginComponent } from './login/login.component';
// import { RegistrationComponent } from './registration/registration.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
// import { AccountComponent } from './account/account.component';
// import { ViewAccountDetailsComponent } from './view-account-details/view-account-details.component';
// import { FundComponent } from './fund/fund.component';
// import { ViewcustomerComponent } from './viewcustomer/viewcustomer.component';
// import { ViewmutualfundComponent } from './viewmutualfund/viewmutualfund.component';
import { Routes, RouterModule } from '@angular/router';
// import { LoginsuccessComponent } from  './loginsuccess/loginsuccess.component';



@NgModule({
  declarations: [
    AppComponent,
    // LoginComponent,
    // RegistrationComponent,
    // AccountComponent,
    // ViewAccountDetailsComponent,
    // FundComponent,
    // LoginsuccessComponent,
    // ViewcustomerComponent,
    // ViewmutualfundComponent
    routingComponents
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
