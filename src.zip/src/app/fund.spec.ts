import { Fund } from './fund';

describe('Fund', () => {
  it('should create an instance', () => {
    expect(new Fund()).toBeTruthy();
  });
});
