import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { RegistrationService } from '../registration.service';
import { User } from '../user';
import { Route } from '@angular/compiler/src/core';
import { Router,ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
user =new User();
msg='';
form:any;
  constructor(private _service : RegistrationService, private _route: Router) {}

  ngOnInit(): void {
  }
  loginUser(){
    this._service.loginUserFromRemote(this.user).subscribe(
      
      data =>{ 
        window.localStorage.setItem("pan", data.pan);

        console.log("response recieved")
      this._route.navigate(['/loginsuccess'])
    },
      error => {console.log("exception occured");
      this.msg="Please enter valid pan and password";
    }
    )
    console.log(this.user);
  }
}
