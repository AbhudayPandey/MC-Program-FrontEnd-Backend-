import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Account } from './account';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  pan:string = window.localStorage.getItem('pan');

  private baseUrl="http://localhost:8081";
  //pan:String;
  // this.pan=window.localStorage.getItem('pan');

  constructor( private _http : HttpClient) { }

  public createAccountFromRemote(account :Account):Observable<any>{
    return this._http.post<any>("http://localhost:8081/Create-Account",account);
  }

  getAccountByPan(): Observable<Account> {
    // return this.http.get<Customer>(`${this.baseUrl}/getCustomer/${userName}`);
    return this._http.get<Account>(`${this.baseUrl}/accountbypan/${this.pan}`).pipe(map((account:any)=>account));
  }
}
