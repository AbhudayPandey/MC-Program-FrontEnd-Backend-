import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { Account } from '../account';
import { Router } from '@angular/router';
import { Route } from '@angular/compiler/src/core';
import { AccountService } from '../account.service';
import { User } from '../user';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  account = new Account();
  msg='';
  // user = new User();
  // pan:String;

  constructor(private _service : AccountService,private _router : Router) { }

  ngOnInit(): void {
    // this.pan=window.localStorage.getItem('pan');
  }


  createAccount(){
    this._service.createAccountFromRemote(this.account).subscribe(
      data =>{
        console.log("response recived");
        this.msg="Account created  successfully";
      },
      error =>{
        console.log("exception occured");
        this.msg=error.error;
      }
    )
  }
}
